from .fmac import main
